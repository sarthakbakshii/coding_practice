export const Contact = () => {
  return <p>Contact no: 123512345</p>;
};
