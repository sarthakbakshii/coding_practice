export const INC_COUNT = "INC_COUNT";
export const DEC_COUNT = "DEC_COUNT";

export const ADD_TODO = "ADD_TODO";

export const ADD_TODO_LOADING = "ADD_TODO_LOADING";
export const ADD_TODO_SUCCESS = "ADD_TODO_SUCCESS";

export const GET_TODO_LOADING = "GET_TODO_LOADING";
export const GET_TODO_SUCCESS = "GET_TODO_SUCCESS";
