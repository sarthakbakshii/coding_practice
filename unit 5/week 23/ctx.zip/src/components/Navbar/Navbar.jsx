import { Cart } from "./Cart";

export const Navbar = () => {
  return <Cart />;
};
