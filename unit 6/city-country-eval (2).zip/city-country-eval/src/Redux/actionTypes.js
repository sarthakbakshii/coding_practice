
export const EDIT_CITY_DATA = "EDIT_CITY_DATA";
export const ADD_CITY_DATA = "ADD_CITY_DATA";
export const ADD_COUNTRY_DATA = "ADD_COUNTRY_DATA";
export const GET_CITY_DATA = "ALL_CITY_DATA";
export const GET_COUNTRY_DATA = "ALL_COUNTRY_DATA"
export const FILTER_CITY_DATA = "FILTER_CITY_DATA"
export const MODAL_DATA = "MODAL_DATA"

export const DELETE_CITY = "DELETE_CITY"

export const SORT_CITY = "SORT_CITY"