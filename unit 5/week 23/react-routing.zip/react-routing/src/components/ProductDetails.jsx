import { useEffect, useState } from "react";
import { useParams } from "react-router-dom"

export const ProductDetails = () => {
    const [product, setProduct] = useState({});
    const {id} = useParams();
    useEffect(() => {
        getData();
    },[])

    const getData = () => {
        fetch(`https://fakestoreapi.com/products/${+id}`)
        .then(res=>res.json())
        .then(d => 
        setProduct(d))
    }
    return <div>
    <div id="divh3"><h3>Product Description</h3></div>
    <div className="card shadow">
    <img src={`${product.image}`} className="card-img-top" alt="..."/>
    <div className="card-body">
    <h6 className="card-title"><b>Product Name : </b>{product.title}</h6>
    <p className="card-text"> <b>Desciption : </b>{product.description}</p>
    </div>
    </div>
    </div>
} 