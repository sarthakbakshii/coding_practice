function showUser(user) {
  const parsedUser = JSON.parse(user);
  alert(parsedUser.first_name);
}

// function updateSubmitHandler(e) {
//   console.log("e", e);
//   e.preventDefault();
//   // return;
//   // e.preventDefault();

//   // console.log(e.target);
// }
