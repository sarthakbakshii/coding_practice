export const About = () => {
  return <div>About us: Pune, 1234</div>;
};
