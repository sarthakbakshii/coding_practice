import { useEffect, useState } from "react"

export const Home = () => {
    const [products, setProducts] = useState([]);
    useEffect(() => {
        data();
    }, [])
    const data = () => {
        fetch('https://fakestoreapi.com/products')
            .then(res=>res.json())
            .then(d => 
            setProducts(d))
    }
    return <>
    <div id="prod"><h3>The total products available : {products.length}</h3></div>
    <h2>Products Category</h2>
    <div className="container">
    {products.map((e, i) => {
        return <div key={i}>
            <p>{e.category}</p>
        </div>
        })}
     </div>
    </>
}