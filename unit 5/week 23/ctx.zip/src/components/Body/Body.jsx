import { Button } from "./Button";

export const Body = () => {
  return <Button></Button>;
};
