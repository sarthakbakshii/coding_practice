function showUser(user) {
  const parsedUser = JSON.parse(user);
  alert(parsedUser.first_name);
}
