import { useState, useEffect } from "react";
import { Link } from "react-router-dom";

export const Products = () => {
    const [products, setProducts] = useState([]);
    useEffect(() => {
        data();
    }, [])
    const data = () => {
        fetch(`https://fakestoreapi.com/products`)
            .then(res=>res.json())
            .then(d => 
            setProducts(d))
    }
    console.log(products)
    return <>
        <div>
        <table className="table table-success table-striped shadow">
         <thead>
          <tr>
            <th>Id</th>
            <th>Name</th>
            <th>Category</th>
            <th>Price</th>
            <th>Rating</th>  
            </tr>   
        </thead>
        <tbody>
        {products.map((e, i) => {
        return <>
        <tr>
            <td>{e.id}</td>
            <td id="name"><Link to={`/products/${e.id}`}>{e.title}</Link></td>
            <td>{e.category}</td>
            <td>₹{e.price}</td>
            <td>{e.rating.rate}</td>
        </tr>    
         </>
        })}
         </tbody> 
        </table>
        </div>
    </>
}